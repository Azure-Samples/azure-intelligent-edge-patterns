# Description

This resource allows the configuration of a Windows Capability.
It can be used for enabling or disabling Windows Capabilities
and configure the desired Loglevel and Logpath.
