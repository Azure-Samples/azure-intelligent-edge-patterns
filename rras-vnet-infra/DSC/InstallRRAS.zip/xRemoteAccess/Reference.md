The following TechNet articles provide reference to the cmdlets used in this DSC module.

[Add-VpnS2SInterface](https://technet.microsoft.com/en-us/library/hh918397.aspx)

[Set-VpnS2SInterface](https://technet.microsoft.com/en-us/library/hh918392.aspx)

[Connect-VpnS2SInterface](https://technet.microsoft.com/en-us/library/hh918440.aspx)

[Disconnect-VpnS2SInterface](https://technet.microsoft.com/en-us/library/hh918423.aspx)

[Install-RemoteAccess](https://technet.microsoft.com/en-us/library/hh918408.aspx)

[Uninstall-RemoteAccess](https://technet.microsoft.com/en-us/library/hh918390.aspx)

[Set-VpnServerIPsecConfiguration](https://technet.microsoft.com/en-us/library/hh918373.aspx)