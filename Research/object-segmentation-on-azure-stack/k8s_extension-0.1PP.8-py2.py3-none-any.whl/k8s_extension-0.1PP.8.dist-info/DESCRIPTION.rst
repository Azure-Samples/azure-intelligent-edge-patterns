Microsoft Azure CLI 'k8s-extension' Extension


