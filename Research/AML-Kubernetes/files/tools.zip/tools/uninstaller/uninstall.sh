#!/bin/bash
input_cluster_name=$1
installer_namespace=$2

CLUSTER_NAME=$(kubectl config view --minify -o jsonpath='{.clusters[0].name}')
if [[ $input_cluster_name != $CLUSTER_NAME ]]; then
    echo "cluster name not match, ${input_cluster_name} ${CLUSTER_NAME}"
    exit 255
fi

helm_components=(kubeflow job-controller amlop prometheus-operator prometheus-instance compute-exporter job-exporter metric-reporter install-job relay-server rest-server device-plugin)

helm_uninstall () {
    namespace=$1
    shift 1
    for component in $@; do
        helm delete $component
        helm delete $component -n $namespace
    done
}

kubectl_delete () {
    namespace=$1
    k8s_type=$2
    name=$3
    kubectl delete $k8s_type $name --ignore-not-found
    kubectl delete $k8s_type $name -n $namespace --ignore-not-found
}

helm_uninstall $installer_namespace ${helm_components[@]}

kubectl_delete $namespace secret cmaks-image-pull-secret
kubectl_delete $namespace configmap compute-config
kubectl_delete $namespace job cmaks-init-job
