#!/bin/bash
cd "$(dirname "$0")"
kubectl_delete () {
    local namespace=$1
    local k8s_type=$2
    local name=$3
    kubectl delete $k8s_type $name --ignore-not-found
    kubectl delete $k8s_type $name -n $namespace --ignore-not-found
}

kube_conf=$(kubectl config view --minify --flatten)
installer_image=$1

if [[ $# == 2 ]]; then
    namespace=$2
else
    namespace="default"
fi

# dependency
kubectl apply -f https://raw.githubusercontent.com/Azure/kubernetes-volume-drivers/master/flexvolume/blobfuse/deployment/blobfuse-flexvol-installer-1.9.yaml

kubectl apply -f https://raw.githubusercontent.com/NVIDIA/k8s-device-plugin/1.0.0-beta6/nvidia-device-plugin.yml

# uninstall installer installed before
# by helm
install_num=$(helm list -n $namespace | grep install-job | wc -l)
if [[ $install_num != 0 ]]; then
    helm uninstall install-job -n $namespace
fi
# by mlc
kubectl_delete azureml job cmaks-init-job
helm template cmaks-init-job install-job-chart/ -n $namespace | kubectl delete -f - --ignore-not-found
# delete secret
kubectl_delete azureml secret cmaks-image-pull-secret

helm install install-job --set kube_conf="$kube_conf" --set image=$installer_image ./install-job-chart  -n $namespace --atomic --create-namespace
